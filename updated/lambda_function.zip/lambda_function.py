def lambda_handler(event, context):
    
    import boto3
    import datetime
    from collections import defaultdict
    import os
    
    m_number = os.environ['mobile_number']
    
    client = boto3.client("sns", region_name="us-east-1")
    cd = boto3.client('ce')
    
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=2)).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    kwargs = dict()
    results=list()
    mylist=list()
    result = defaultdict(int)
    
    data=cd.get_cost_and_usage(TimePeriod={'Start': start, 'End':  end}, Granularity='DAILY', Metrics=['UnblendedCost'], GroupBy=[{'Type': 'DIMENSION', 'Key': 'LINKED_ACCOUNT'}, {'Type': 'DIMENSION', 'Key': 'SERVICE'}], **kwargs)
    
    results += data['ResultsByTime']
    
    for result_by_time in results:
        for group in result_by_time['Groups']:
            amount = group['Metrics']['UnblendedCost']['Amount']
            unit = group['Metrics']['UnblendedCost']['Unit']
            mylist.append([result_by_time['TimePeriod']['Start'],  amount])
    
    for fruit, value in mylist:
        result[fruit] += float(value)
    result =  result.items()
    
    client.publish( PhoneNumber=m_number, Message= 'Personal2 '+str(result),
       MessageAttributes={'AWS.SNS.SMS.SMSType': { 'DataType': 'String', 'StringValue': 'Transactional' } } )
    
    return (str(result))